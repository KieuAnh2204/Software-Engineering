# FoodFast Delivery

## Overview

FoodFast Delivery is a full-stack food delivery web application that connects customers with restaurants. The platform features a customer-facing website for browsing restaurants, ordering food, and tracking deliveries, along with an admin dashboard for managing restaurants, menu items, orders, and users.

The application is built as a monorepo with a React/TypeScript frontend and Express.js backend, using PostgreSQL with Drizzle ORM for data persistence. The design follows modern food delivery platform patterns (inspired by Uber Eats, DoorDash, Deliveroo) with emphasis on food-first visual hierarchy and seamless user experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript
- Vite as build tool and dev server
- Wouter for client-side routing
- TanStack Query for server state management
- shadcn/ui component library built on Radix UI primitives
- Tailwind CSS for styling with custom design tokens

**Component Structure:**
- Page components organized in `client/src/pages/` (Home, RestaurantDetail, Cart, Checkout, Profile, Login, AdminDashboard)
- Reusable UI components in `client/src/components/` (Header, Hero, RestaurantCard, MenuItemCard, CartSheet, OrderStatusStepper)
- Admin-specific components in `client/src/components/admin/`
- Design system components in `client/src/components/ui/`

**State Management:**
- Context-based authentication with separate contexts:
  - `AuthContext` for customer users
  - `RestaurantOwnerAuthContext` for restaurant owners
  - `AdminAuthContext` for admin users
- Local storage persistence for user sessions
- Theme management via `ThemeProvider` context
- Backend authentication with role-based access control

**Routing Strategy:**
- Customer routes: `/`, `/restaurant/:id`, `/cart`, `/checkout`, `/login`, `/profile`
- Restaurant Owner routes: `/owner/login`, `/owner` (dashboard with menu and order management)
- Admin routes: `/admin/login`, `/admin` (dashboard with monitoring and system logs)
- 404 handling with custom NotFound page

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js
- TypeScript with ES modules
- PostgreSQL database (via Neon serverless)
- Drizzle ORM for type-safe database queries
- Session management prepared (connect-pg-simple)

**Current Implementation:**
- Minimal server setup in `server/index.ts` with middleware for JSON parsing, URL encoding, and request logging
- Routes structure defined but not yet implemented (`server/routes.ts`)
- Storage abstraction layer (`server/storage.ts`) with interface pattern for future database integration
- In-memory storage implementation as placeholder (`MemStorage` class)

**Database Schema:**
- **Users table**: id, username, password, role, email, restaurantName
- **Dishes table**: Menu items with availability tracking
- **Orders table**: Order details with customer info, status, and timestamps
- **Activity Logs table**: Tracks all restaurant owner actions for admin monitoring
- **Restaurant Status table**: Store open/closed status
- Schema uses Drizzle's PostgreSQL adapter with UUID generation
- Zod validation schemas for type-safe inserts
- Database migrations configured to output to `./migrations`

**Planned Architecture:**
The requirements document indicates a microservices architecture with:
- User Service (authentication, user management)
- Restaurant Service (restaurants and menu items)
- Order Service (cart, orders, order status)
- Notification Service (email notifications)
- RabbitMQ for inter-service communication
- Docker Compose for containerization

However, the current codebase implements a monolithic architecture, suggesting a phased development approach starting with a simpler structure.

### Design System

**Visual Design:**
- Custom color palette defined for light/dark modes in `client/src/index.css`
- Primary green color (142 75% 45%) for appetite appeal
- Typography: Inter for UI/body, Poppins for headings
- Custom elevation system with hover/active states (`--elevate-1`, `--elevate-2`)
- Responsive design with mobile-first approach

**Component Patterns:**
- Consistent use of shadcn/ui primitives for accessibility
- Custom styling variants for buttons, badges, cards
- Theme-aware components with CSS variable system
- Reusable patterns for restaurant and menu item displays

### Authentication & Authorization

**Three User Roles:**
1. **Customer** (`role: "customer"`)
   - Browse restaurants and order food
   - Cart and checkout functionality
   - Order tracking
   - Profile management

2. **Restaurant Owner** (`role: "restaurant_owner"`)
   - Manage menu items (add, edit, delete, toggle availability)
   - View and manage orders
   - Update order delivery status
   - Toggle restaurant open/closed status
   - All actions are logged for admin monitoring

3. **Admin** (`role: "admin"` or `role: "superadmin"`)
   - Full system oversight
   - View all restaurant owner activities via Activity Logs
   - Manage users, restaurants, and system settings
   - Access to system logs and analytics

**Authentication Implementation:**
- Backend authentication API at `/api/auth/owner/login` and `/api/auth/admin/login`
- Role-based access validation on both frontend and backend
- Local storage persistence for user sessions
- Protected routes requiring authentication and role verification

**Test Credentials:**
- Restaurant Owner: `username: owner`, `password: owner123`
- Admin: `username: admin`, `password: admin123`

### Order Management System

**Order Flow:**
- Cart management with quantity controls
- Checkout with payment method selection (cash, bank transfer, card)
- Delivery address management
- Order status tracking with visual stepper component
- Status progression: pending → preparing → delivering (by drone) → completed

**Admin Order Management:**
- Order list with filtering by status
- Detailed order view with customer and restaurant information
- Order status updates
- Revenue tracking and analytics

## External Dependencies

### UI Component Library
- **shadcn/ui**: Provides accessible, customizable UI components built on Radix UI primitives
- **Radix UI**: Headless component library for complex UI patterns (dialogs, dropdowns, accordions, etc.)
- All UI components customized through Tailwind CSS with consistent design tokens

### Database & ORM
- **Neon Serverless PostgreSQL**: Cloud-hosted PostgreSQL database (configured via `DATABASE_URL` environment variable)
- **Drizzle ORM**: Type-safe ORM with schema-first approach and migration support
- **drizzle-kit**: CLI tool for schema migrations and database management

### Styling & Design
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- Custom design system defined in `tailwind.config.ts` and `client/src/index.css`
- Google Fonts: Inter and Poppins font families

### Development Tools
- **Vite**: Fast build tool with HMR and optimized production builds
- **TypeScript**: Type safety across frontend and backend
- **Replit plugins**: Runtime error overlay, cartographer, and dev banner for Replit environment

### Data Validation
- **Zod**: Schema validation library integrated with Drizzle for runtime type checking
- **@hookform/resolvers**: Form validation integration

### Asset Management
- Static assets stored in `attached_assets/` directory
- Generated images for restaurants and food items
- Image imports handled through Vite's asset pipeline

### Future Integrations (Planned)
- **RabbitMQ**: Message broker for microservices communication (referenced in requirements)
- **Email Service**: For order confirmation notifications
- **Payment Gateway**: For processing payments (currently mock implementation)
- **JWT**: For token-based authentication
- **Docker Compose**: For containerization and deployment